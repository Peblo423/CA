#!/bin/bash

LOGFILE="2Stress.log"

INTERVALO=5

prueba="stress -c 2 -m 4 -d 1 --timeout 30"

echo "prueba de stress iniciada a las $(date)" > $LOGFILE

$prueba &

PID=$!

while kill -0 $PID 2>/dev/null; do
	echo "Tiempo: $(date)" >> $LOGFILE
	echo "Uso de CPU y RAM:" >> $LOGFILE
	top -bn1 | grep "Cpu(s)" >> $LOGFILE
	free -h | grep "mem" >> $LOGFILE
	echo "uso de disco: " >> $LOGFILE
	df -h | grep "/dev/sd" >> $LOGFILE
	echo "------------------------" >> $LOGFILE

	CPU_USAGE=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)
	if (( ${CPU_USAGE%.*} >= 90 )); then
		echo "ALERTA: el uso de la cpu supero el 90% $CPU_USAGE%" | tee -a $LOGFILE
	fi

	sleep $INTERVALO
done

echo "prueba de stress finalaizada a las $(date)" >> $LOGFILE
echo "log guardado en $LOGFILE"
