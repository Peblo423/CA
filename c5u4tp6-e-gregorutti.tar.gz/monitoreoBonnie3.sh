#!/bin/bash

LOGFILE="monitoreoBonnie3.log"

INTERVALO=5

prueba="bonnie++ -d /home -s 5G -r 1G -u $(whoami)"

echo "prueba de Bonnie++ iniciada a las $(date)" > $LOGFILE

$prueba &

PID=$!

while kill -0 $PID 2>/dev/null; do
	echo "Tiempo: $(date)" >> $LOGFILE
	echo "uso de disco: " >> $LOGFILE
	df -h | grep "/dev/sd" >> $LOGFILE
	echo "------------------------" >> $LOGFILE

	sleep $INTERVALO
done

echo "prueba de BONNIE++ finalaizada a las $(date)" >> $LOGFILE
echo "log guardado en $LOGFILE"
