#!/bin/bash

LOGFILE="monitoreo1stress.log"

INTERVALO=5

prueba="stress -c 4 -m 2 -d 1 --timeout 30"

echo "prueba de stress iniciada a las $(date)" > $LOGFILE

$prueba &

PID=$!

while kill -0 $PID 2>/dev/null; do
	echo "Tiempo: $(date)" >> $LOGFILE
	echo "Uso de CPU y RAM:" >> $LOGFILE
	top -bn1 | grep "cpu(s)" >> $LOGFILE
	free -h | grep "mem" >> $LOGFILE
	echo "uso de disco: " >> $LOGFILE
	df -h | grep "/dev/sd" >> $LOGFILE
	echo "------------------------" >> $LOGFILE

	sleep $INTERVALO
done

echo "prueba de stress finalaizada a las $(date)" >> $LOGFILE
echo "log guardado en $LOGFILE"
