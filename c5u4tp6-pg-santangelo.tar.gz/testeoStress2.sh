LOGFILE="monitoreo2.log"

PRUEBA="stress -c 1 -m 2 -d 1 --timeout 20"

echo "Prueba iniciada a las $(date)" > $LOGFILE

$PRUEBA &

PID=$!

while kill -0 $PID 2>/dev/null; do
	echo "Tiempo: &(date)" >> $LOGFILE
	echo "Uso de CPU y RAM:" >> $LOGFILE
	top -bn1 | grep "Cpu(s)" >> $LOGFILE
	free -h | grep "Mem" >> $LOGFILE
	echo "Uso de disco:" >> $LOGFILE
	df -h | grep "/dev/sd" >> $LOGFILE
	echo "-------------------------" >> $LOGFILE
	sleep 5
done

echo "Prueba stress finalizada a las $(date)" >> $LOGFILE
echo "Log guardado en $LOGFILE"
	
	
