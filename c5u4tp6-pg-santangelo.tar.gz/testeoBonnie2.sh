LOGFILE="monitoreoB2.log"

PRUEBA="bonnie++ -d /home/pablo -s 500M -r 2G -u $(whoami)"

echo "Prueba bonnie iniciada a las $(date)" > $LOGFILE

$PRUEBA &

PID=$!

while kill -0 $PID 2>/dev/null; do
	echo "Tiempo: &(date)" >> $LOGFILE
	echo "Uso de disco:" >> $LOGFILE
	df -h | grep "/dev/sd" >> $LOGFILE
	echo "-------------------------" >> $LOGFILE
	sleep 15
done

echo "Prueba bonnie finalizada a las $(date)" >> $LOGFILE
echo "Log guardado en $LOGFILE"
	
	
